package com.foundation.foundation.system.service;
import com.foundation.foundation.system.repository.FoundationRepository;
import com.foundation.foundation.system.model.foundation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class foundationServiceImplimentation implements FoundationService{
    @Autowired
    private FoundationRepository foundationRepositary;

    @Override
    public foundation saveFoundation(foundation foundation) {
        return foundationRepositary.save(foundation);
    }

    @Override
    public List<foundation> getAllFoundations() {
        return foundationRepositary.findAll();
    }
}
