package com.foundation.foundation.system.service;

import com.foundation.foundation.system.model.foundation;

import java.util.List;

public interface FoundationService {
    public foundation saveFoundation(foundation foundation);
    public List<foundation> getAllFoundations();
}
