package com.foundation.foundation.system.service;

import com.foundation.foundation.system.model.Application;
import com.foundation.foundation.system.repository.ScholarshipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApplicationServiceImpl implements ApplicationService{
    @Autowired
    private ScholarshipRepository scholarshipRepository;

    @Override
    public Application saveApplication(Application application) {
        return scholarshipRepository.save(application);
    }

    @Override
    public List<Application> getAllApplications() {
        return scholarshipRepository.findAll();
    }
}
