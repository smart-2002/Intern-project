package com.foundation.foundation.system.controller;

import com.foundation.foundation.system.exception.ResourceNotFoundException;
import com.foundation.foundation.system.model.LoginStatus;
import com.foundation.foundation.system.model.foundation;
import com.foundation.foundation.system.repository.FoundationRepository;
import com.foundation.foundation.system.service.FoundationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/foundation")
@CrossOrigin("*")

public class foundationController {
    @Autowired
    private FoundationService foundationService;
    @Autowired
    private FoundationRepository foundationRepository;

    @PostMapping("/add")
    public String add(@RequestBody foundation foundation){
        foundationService.saveFoundation(foundation);
        return "New foundation is added";
    }

    @GetMapping("getAll")
    public List<foundation> getAllFoundation(){
        return foundationService.getAllFoundations();
    }

    @PostMapping("/register")
    public LoginStatus registerFoundation(@RequestBody foundation newFoundation) {
        List<foundation> foundations = foundationRepository.findAll();
        //System.out.println("New user: " + newUser.toString());
        for (foundation foundation : foundations) {
            //System.out.println("Registered user: " + newUser.toString());
            if (foundation.equals(newFoundation)) {
                LoginStatus loginStatus = new LoginStatus();
                loginStatus.setStatusMessage("Foundation Already Exists");
                return loginStatus;
            }
        }
        foundationRepository.save(newFoundation);
        LoginStatus loginStatus = new LoginStatus();
        loginStatus.setStatusMessage("Foundation Registered Successfully");
        return loginStatus;
    }

    @PostMapping("/login")
    public LoginStatus loginFoundation(@Valid @RequestBody foundation foundation) {
        List<foundation> foundations = foundationRepository.findAll();
        for (foundation other : foundations) {
            if (other.equals(foundation)) {
                LoginStatus loginStatus = new LoginStatus();
                loginStatus.setId(other.getFoundation_id());
                loginStatus.setStatusMessage("Success");
                return loginStatus;
            }
        }
        LoginStatus loginStatus = new LoginStatus();
        loginStatus.setStatusMessage("Failure");
        return loginStatus;
    }

//    //build delete Instructor REST API
//    @DeleteMapping("/{student_id}")
//    public ResponseEntity<HttpStatus> deleteStudent(@PathVariable int student_id){
//
//        Student student = studentRepository.findById(student_id)
//                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+ student_id));
//
//        studentRepository.delete(student);
//        return new ResponseEntity<>(HttpStatus.NO_CONTENT) ;
//    }
//
//    @PostMapping("/users/logout")
//    public LoginStatus logStudentOut(@Valid @RequestBody Student student) {
//        List<Student> students = studentRepository.findAll();
//        for (Student other : students) {
//            if (other.equals(student)) {
//                LoginStatus loginStatus = new LoginStatus();
//                loginStatus.setId(other.getStudent_id());
//                loginStatus.setStatusMessage("Success");
//                return loginStatus;
//            }
//        }
//        LoginStatus loginStatus = new LoginStatus();
//        loginStatus.setStatusMessage("Failure");
//        return loginStatus;
//    }

    //build Get Instructor By Id REST API
    @GetMapping("/{foundation_id}")
    public ResponseEntity<foundation> getFoundationById(@PathVariable int foundation_id){
        foundation foundation = foundationRepository.findById(foundation_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+foundation_id));
        return ResponseEntity.ok(foundation);
    }

}
