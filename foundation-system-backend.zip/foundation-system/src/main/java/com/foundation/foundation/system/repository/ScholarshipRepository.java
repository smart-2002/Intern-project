package com.foundation.foundation.system.repository;

import com.foundation.foundation.system.model.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ScholarshipRepository extends JpaRepository<Application,Integer> {
}
