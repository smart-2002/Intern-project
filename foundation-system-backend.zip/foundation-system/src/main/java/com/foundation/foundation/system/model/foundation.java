package com.foundation.foundation.system.model;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "foundation1")
public class foundation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int foundation_id;
    private String name;
    private String email;
    private String location;
    private String phone_no;
    private String website;
    private String des;
    private int no_of_seats;
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public foundation() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        foundation that = (foundation) o;
        return Objects.equals(email, that.email) && Objects.equals(password, that.password);
    }

    @Override
    public int hashCode() {
        return Objects.hash(foundation_id, name, email, location, phone_no, website, des, no_of_seats, password);
    }

    public foundation(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public int getFoundation_id() {
        return foundation_id;
    }

    public void setFoundation_id(int foundation_id) {
        this.foundation_id = foundation_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public int getNo_of_seats() {
        return no_of_seats;
    }

    public void setNo_of_seats(int no_of_seats) {
        this.no_of_seats = no_of_seats;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
