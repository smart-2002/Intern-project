package com.foundation.foundation.system.controller;

import com.foundation.foundation.system.model.LoginStatus;
import com.foundation.foundation.system.model.User;
import com.foundation.foundation.system.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;

@CrossOrigin("*")
@RestController
public class UserController {
    @Autowired
    UserRepository userRepository;
    @PostMapping("/users/register")
    public LoginStatus registerUser(@RequestBody User newUser) {
        List<User> users = userRepository.findAll();
        //System.out.println("New user: " + newUser.toString());
        for (User user : users) {
            System.out.println("Registered user: " + newUser.toString());
            if (user.equals(newUser)) {
                LoginStatus loginStatus = new LoginStatus();
                loginStatus.setStatusMessage("User Already Exists");
                return loginStatus;
            }
        }
        userRepository.save(newUser);
        LoginStatus loginStatus = new LoginStatus();
        loginStatus.setStatusMessage("User Registered Successfully");
        return loginStatus;
    }
    @PostMapping("/users/login")
    public LoginStatus loginUser(@Valid @RequestBody User user) {
        List<User> users = userRepository.findAll();
        for (User other : users) {
            if (other.equals(user)) {
                user.setLoggedIn(true);
                userRepository.save(user);
                LoginStatus loginStatus = new LoginStatus();
                loginStatus.setStatusMessage("Success");
                return loginStatus;
            }
        }
        LoginStatus loginStatus = new LoginStatus();
        loginStatus.setStatusMessage("Failure");
        return loginStatus;
    }
    @PostMapping("/users/logout")
    public Status logUserOut(@Valid @RequestBody User user) {
        List<User> users = userRepository.findAll();
        for (User other : users) {
            if (other.equals(user)) {
                user.setLoggedIn(false);
                userRepository.save(user);
                return Status.SUCCESS;
            }
        }
        return Status.FAILURE;
    }
    @DeleteMapping("/users/all")
    public Status deleteUsers() {
        userRepository.deleteAll();
        return Status.SUCCESS;
    }
}