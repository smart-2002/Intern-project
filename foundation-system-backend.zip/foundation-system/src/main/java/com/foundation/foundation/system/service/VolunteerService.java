package com.foundation.foundation.system.service;

import com.foundation.foundation.system.model.Volunteer;

import java.util.List;

public interface VolunteerService {

    public Volunteer saveVolunteer(Volunteer volunteer);

    public List<Volunteer> getAllVolunteers();
}
