package com.foundation.foundation.system.controller;

import com.foundation.foundation.system.exception.ResourceNotFoundException;
import com.foundation.foundation.system.model.Application;
import com.foundation.foundation.system.model.Volunteer;
import com.foundation.foundation.system.repository.VolunteerRepository;
import com.foundation.foundation.system.service.VolunteerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/volunteer")
@CrossOrigin("*")
@RestController
public class VolunteerController {

    @Autowired
    private VolunteerRepository volunteerRepository;
    @Autowired
    private VolunteerService volunteerService;

    @PostMapping("add")
    public String add(@RequestBody Volunteer volunteer){
        volunteerService.saveVolunteer(volunteer);
        return "New student is added";
    }

    @GetMapping("{volunteer_id}")
    public ResponseEntity<Volunteer> getVolunteerById(@PathVariable int volunteer_id){
        Volunteer volunteer = volunteerRepository.findById(volunteer_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+volunteer_id));
        return ResponseEntity.ok(volunteer);
    }

    @GetMapping("getAll")
    public List<Volunteer> getAllVolunteers(){
        return volunteerService.getAllVolunteers();
    }

    //build delete Instructor REST API
    @DeleteMapping("/{volunteer_id}")
    public ResponseEntity<HttpStatus> deleteApplication(@PathVariable int volunteer_id){

        Volunteer volunteer = volunteerRepository.findById(volunteer_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+ volunteer_id));

        volunteerRepository.delete(volunteer);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT) ;
    }
}
