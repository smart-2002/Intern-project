package com.foundation.foundation.system.controller;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.foundation.foundation.system.exception.ResourceNotFoundException;
import com.foundation.foundation.system.model.LoginStatus;
import com.foundation.foundation.system.model.Student;
import com.foundation.foundation.system.model.User;
import com.foundation.foundation.system.model.Volunteer;
import com.foundation.foundation.system.repository.StudentRepository;
import com.foundation.foundation.system.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/Student")
@CrossOrigin("*")

public class StudentController {
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private StudentService studentService;

    @PostMapping("/add")
    public String add(@RequestBody Student student){
        studentService.saveStudent(student);
        return "New student is added";
    }

    @PostMapping("/register")
    public LoginStatus registerStudent(@RequestBody Student newStudent) {
        List<Student> students = studentRepository.findAll();
        //System.out.println("New user: " + newUser.toString());
        for (Student student : students) {
            //System.out.println("Registered user: " + newUser.toString());
            if (student.equals(newStudent)) {
                LoginStatus loginStatus = new LoginStatus();
                loginStatus.setStatusMessage("User Already Exists");
                return loginStatus;
            }
        }
        studentRepository.save(newStudent);
        LoginStatus loginStatus = new LoginStatus();
        loginStatus.setStatusMessage("User Registered Successfully");
        return loginStatus;
    }

    @PostMapping("/login")
    public LoginStatus loginStudent(@Valid @RequestBody Student student) {
        List<Student> students = studentRepository.findAll();
        for (Student other : students) {
            if (other.equals(student)) {
                LoginStatus loginStatus = new LoginStatus();
                loginStatus.setId(other.getStudent_id());
                loginStatus.setStatusMessage("Success");
                return loginStatus;
            }
        }
        LoginStatus loginStatus = new LoginStatus();
        loginStatus.setStatusMessage("Failure");
        return loginStatus;
    }

    //build Get Instructor By Id REST API
    @GetMapping("/status/{student_id}")
    public ResponseEntity<String> getStudentstatusById(@PathVariable int student_id){
        Student  student = studentRepository.findById(student_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+student_id));
        String status= student.getStatus();
        return ResponseEntity.ok(status);
    }

    @GetMapping("getAll")
    public List<Student> getAllStudents(){
        return studentService.getAllStudents();
    }

    //build delete Instructor REST API
    @DeleteMapping("/{student_id}")
    public ResponseEntity<HttpStatus> deleteStudent(@PathVariable int student_id){

        Student student = studentRepository.findById(student_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+ student_id));

        studentRepository.delete(student);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT) ;
    }

    @PostMapping("/users/logout")
    public LoginStatus logStudentOut(@Valid @RequestBody Student student) {
        List<Student> students = studentRepository.findAll();
        for (Student other : students) {
            if (other.equals(student)) {
                LoginStatus loginStatus = new LoginStatus();
                loginStatus.setId(other.getStudent_id());
                loginStatus.setStatusMessage("Success");
                return loginStatus;
            }
        }
        LoginStatus loginStatus = new LoginStatus();
        loginStatus.setStatusMessage("Failure");
        return loginStatus;
    }

    //build Get Instructor By Id REST API
    @GetMapping("/{student_id}")
    public ResponseEntity<Student> getStudentById(@PathVariable int student_id){
        Student student = studentRepository.findById(student_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+student_id));
        return ResponseEntity.ok(student);
    }

    //build update Instructor REST API
    @PutMapping("status/{student_id}")
    public ResponseEntity<Student> updateStudentstatus(@PathVariable int student_id,@RequestBody Student studentDetails){
        Student updateStudentstatus = studentRepository.findById(student_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+ student_id));
        updateStudentstatus.setStatus(studentDetails.getStatus());
//        updateStudentstatus.setStudent_id(student_id);
//        updateStudentstatus.setStudent_name(studentDetails.getStudent_name());
//        updateStudentstatus.setPhone_number(studentDetails.getPhone_number());
//        updateStudentstatus.setEmail(studentDetails.getEmail());
//        updateStudentstatus.setLocation(studentDetails.getLocation());
//        updateStudentstatus.setGender(studentDetails.getGender());
//        updateStudentstatus.setDesci(studentDetails.getDesci());
//        updateStudentstatus.setCutoff(studentDetails.getCutoff());
//        updateStudentstatus.setStream(studentDetails.getStream());
//        updateStudentstatus.setSchool_type(studentDetails.getSchool_type());
        studentService.saveStudent(updateStudentstatus);
        return ResponseEntity.ok(updateStudentstatus);
    }

    //build update Instructor REST API
    @JsonProperty("student_id")
    @PutMapping("/update/{student_id}")
    public ResponseEntity<Student> updateStudent(@PathVariable int student_id, @RequestBody Student studentDetails){
        Student updateStudent = studentRepository.findById(student_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+ student_id));
        updateStudent.setStudent_name(studentDetails.getStudent_name());
        updateStudent.setPhone_number(studentDetails.getPhone_number());
        updateStudent.setEmail(studentDetails.getEmail());
        updateStudent.setLocation(studentDetails.getLocation());
        updateStudent.setGender(studentDetails.getGender());
        updateStudent.setDesci(studentDetails.getDesci());
        updateStudent.setCutoff(studentDetails.getCutoff());
        updateStudent.setStream(studentDetails.getStream());
        updateStudent.setSchool_type(studentDetails.getSchool_type());

        studentService.saveStudent(updateStudent);
        return ResponseEntity.ok(updateStudent);
    }
}
