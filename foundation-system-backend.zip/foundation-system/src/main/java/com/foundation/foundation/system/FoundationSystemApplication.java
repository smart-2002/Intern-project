package com.foundation.foundation.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoundationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoundationSystemApplication.class, args);
	}

}
