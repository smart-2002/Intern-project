package com.foundation.foundation.system.controller;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.foundation.foundation.system.exception.ResourceNotFoundException;
import com.foundation.foundation.system.model.Application;
import com.foundation.foundation.system.model.Student;
import com.foundation.foundation.system.repository.ScholarshipRepository;
import com.foundation.foundation.system.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/application")
@CrossOrigin("*")
@RestController
public class ApplicationController {
    @Autowired
    private ScholarshipRepository scholarshipRepository;
    @Autowired
    private ApplicationService applicationService;

    @PostMapping("add")
    public String add(@RequestBody Application application){
        applicationService.saveApplication(application);
        return "New application is added";
    }

    @JsonProperty("application_id")
    @PutMapping("/update/{application_id}")
    public ResponseEntity<Application> updateApplication(@PathVariable int application_id, @RequestBody Application application){
        Application updateApplication = scholarshipRepository.findById(application_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+ application_id));
        updateApplication.setName(application.getName());
        updateApplication.setOpendate(application.getOpendate());
        updateApplication.setClosedate(application.getClosedate());
        updateApplication.setGuideline(application.getGuideline());
        updateApplication.setLink(application.getLink());

        applicationService.saveApplication(updateApplication);
        return ResponseEntity.ok(updateApplication);
    }

    @GetMapping("{application_id}")
    public ResponseEntity<Application> getApplicationById(@PathVariable int application_id){
        Application application = scholarshipRepository.findById(application_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+application_id));
        return ResponseEntity.ok(application);
    }

    @GetMapping("getAll")
    public List<Application> getAllVolunteers(){
        return applicationService.getAllApplications();
    }

    //build delete Instructor REST API
    @DeleteMapping("/{application_id}")
    public ResponseEntity<HttpStatus> deleteApplication(@PathVariable int application_id){

        Application application = scholarshipRepository.findById(application_id)
                .orElseThrow(()->new ResourceNotFoundException("Instructor Not Found With Id: "+ application_id));

        scholarshipRepository.delete(application);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT) ;
    }
}
