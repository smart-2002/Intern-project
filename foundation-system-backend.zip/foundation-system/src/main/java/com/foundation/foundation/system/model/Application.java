package com.foundation.foundation.system.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "shcolarship")
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int application_id;
    private String name;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date opendate;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date closedate;

//    private Byte guideline;

    private String guideline;
    private String link;

    public Application() {
    }

    public int getApplication_id() {
        return application_id;
    }

    public void setApplication_id(int application_id) {
        this.application_id = application_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getOpendate() {
        return opendate;
    }

    public void setOpendate(Date opendate) {
        this.opendate = opendate;
    }

    public Date getClosedate() {
        return closedate;
    }

    public void setClosedate(Date closedate) {
        this.closedate = closedate;
    }

    public String getGuideline() {
        return guideline;
    }

    public void setGuideline(String guideline) {
        this.guideline = guideline;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

//    public byte[] getGuideline() {
//        return guideline;
//    }
//
//    public void setGuideline(byte[] guideline) {
//        this.guideline = guideline;
//    }
}
