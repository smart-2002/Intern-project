package com.foundation.foundation.system.service;

import com.foundation.foundation.system.model.Application;

import java.util.List;

public interface ApplicationService {
    public Application saveApplication(Application application);

    public List<Application> getAllApplications();
}
