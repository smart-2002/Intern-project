package com.foundation.foundation.system.controller;

public enum Status {
    SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE
}
