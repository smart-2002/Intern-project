import React, { useState } from "react";

function Func3(){
const[food,setFood]=useState(

  [
        {
          id: 1,
          title: 'buttermilk pancakes',
          category: 'breakfast',
          price: 15.99,
          desc:` I'm baby woke mlkshk wolf bitters live-edge blue bottle, hammock freegan copper mug whatever cold-pressed` ,
        },
        {
          id: 2,
          title: 'diner double',
          category: 'lunch',
          price: 13.99,
          desc: `vaporware iPhone mumblecore selvage raw denim slow-carb leggings gochujang`
        },
        {
          id: 3,
          title: 'godzilla milkshake',
          category: 'shakes',
          price: 6.99,
          desc:` ombucha chillwave fanny pack 3 wolf moon street art photo booth before they sold out organic viral.`,
        },
        {
          id: 4,
          title: 'country delight',
          category: 'breakfast',
          price: 20.99,
          desc: `Shabby chic keffiyeh neutra snackwave pork belly shoreditch. Prism austin mlkshk truffaut` ,
        },
        {
          id: 5,
          title: 'egg attack',
          category: 'lunch',
          price: 22.99,
          desc: `franzen vegan pabst bicycle rights kickstarter pinterest meditation farm-to-table 90's pop-up` ,
        },
       
    ]
)
const[datarender,setDatarender]=useState(food)
const items = food.map(f=>f.category)
// console.log(items)
const uniqitem = [...new Set(items)]
// console.log(uniqitem)
uniqitem.unshift("All")

const handlechange=(ch)=>{
    // console.log("show" ,ch)
    if(ch === "All"){
        setDatarender(food)
        return
    }
  const filterdata=food.filter(data=>data.category===ch)
   setDatarender(filterdata)
}
    return(

        <div>
            {uniqitem.map(uni=><span onClick={()=>handlechange(uni)} className="menu1">{uni}</span>)}
  <div className="box1">
  {datarender.map(f =><div className="header1"><h3 className="head1"><p className="title1">{f.title} ...<p className="price1">{f.price}</p></p><p className="content1">{f.desc}</p></h3></div>)}
  </div>

        </div>
    )
}
export default Func3