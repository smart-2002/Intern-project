import React, { useState } from 'react';
import '../form/Form.css'
import logo from '../asserts/LOGO.png' 
import 'bootstrap/dist/css/bootstrap.min.css';
import Form from 'react-bootstrap/Form';
import { Navigate, useNavigate } from 'react-router';

const FoundationUpdate = () => {
    const[name,setName]=useState('')
    const[location,setLocation]=useState('')
    const[phone_no,setPhone_number]=useState('')
    const[no_of_seats,setNo_of_seats]=useState('')
    const[des,setDescription]=useState('')
    const[website,setWebsite]=useState('')
    const[email,setEmail]=useState('')
    const password=`${name}`+"2204"
    const navigate=useNavigate()
    const handleClick=(e)=>{
        e.preventDefault()
        const foundation={name,phone_no,location,no_of_seats,des,website,email,password}
        console.log(foundation)
        fetch("http://localhost:8080/foundation/register",{
            method:"POST",
            headers:{"content-type":"application/json"},
            body:JSON.stringify(foundation)
        })
        .then(res=>res.json())
        .then((result)=>{
            console.log(result)
            console.log(result.statusMessage)
            if(result.statusMessage==="Foundation Already Exists"){
                alert("Foundation Already Exists please Enter New Details..");
                return result;
            }
            else if(result.statusMessage==="Foundation Registered Successfully"){
                console.log("New foundation added");
                alert("Successfully added your profile\nYour user name:"+`${email}`+"\nYour password is:"+`${password}`);
                navigate('/');
            return result;
            }
            })
    }

    return (
        <div>
            <div className='card-index' style={{margin:'4% -35% 0px 35%'}} >
               <div className='card-body'> <img src={logo} className='logo '/>
                <p className='headline1'>Foundation Registeration</p>
                <div className='inputer'>
                  <Form.Control type="text" placeholder= 'Foundation Name' className='loginput1' 
                  value={name} onChange={(e)=>setName(e.target.value)}/>
                  <Form.Control type="text" placeholder="Location" className='loginput1' 
                  value={location} onChange={(e)=>setLocation(e.target.value)}/>
                  <Form.Control type="number" placeholder= 'Phone No' className='loginput1' 
                  value={phone_no} onChange={(e)=>setPhone_number(e.target.value)}/>
                  <Form.Control type="email" placeholder= 'Email' className='loginput1' 
                  value={email} onChange={(e)=>setEmail(e.target.value)}/>
                  <Form.Control type="text" placeholder="Website" className='loginput1' 
                  value={website} onChange={(e)=>setWebsite(e.target.value)}/>
                  <Form.Control type="number" placeholder= 'Number of Seats' className='loginput1' 
                  value={no_of_seats} onChange={(e)=>setNo_of_seats(e.target.value)}/>
                  <Form.Control type="text" placeholder="Description" className='loginput1' 
                  value={des} onChange={(e)=>setDescription(e.target.value)}/>
                  <button className='logbtn' onClick={handleClick}>Register</button>
                  </div>
                </div>
            </div>
            
        </div>
    );
}
 
export default FoundationUpdate;