import React, { useEffect, useState } from 'react';
import '../form/Form.css'
import logo from '../asserts/LOGO.png' 
import 'bootstrap/dist/css/bootstrap.min.css';
import Form from 'react-bootstrap/Form';
import { useNavigate, useParams } from 'react-router';
import StudentService from '../service/StudentService';
import { Link } from 'react-router-dom';

const Studentupdate = () => {
    const[student_name,setStudent_name]=useState('')
    const[location,setLocation]=useState('')
    const[phone_number,setPhone_number]=useState('')
    const[gender,setGender]=useState('')
    const[desci,setDescription]=useState('')
    const[cutoff,setCutoff]=useState('')
    const[stream,setStream]=useState('')
    const[school_type,setSchool_type]=useState('')
    const[email,setEmail]=useState('')

    const navigate = useNavigate();
  const {id1} = useParams();
  

  const handleClick=(e)=>{
    e.preventDefault()
    const student={student_name,phone_number,location,gender,desci,cutoff,stream,school_type,email}
    console.log(student)
    fetch(`http://localhost:8080/Student/update/${id1}`,{
        method:"PUT",
        headers:{"content-type":"application/json"},
        body:JSON.stringify(student)
    }).then(()=>{console.log("Updated")})
    .then(()=>{alert("updated....")})
    navigate(`/Student-home/${id1}`)

  }

  useEffect(() => {
    StudentService.getStudentById(id1).then((response) =>{
        setLocation(response.data.location)
        setStudent_name(response.data.student_name)
        setEmail(response.data.email)
        setGender(response.data.gender)
        setPhone_number(response.data.phone_number)
        setStream(response.data.stream)
        setSchool_type(response.data.school_type)
        setDescription(response.data.desci)
        setCutoff(response.data.cutoff)
    }).catch(error=>{
        console.log(error)
    })
  },[])

    return (
        <div>
            <div className='card-index' style={{margin:'4% -35% 0px 35%'}} >
               <div className='card-body'> <img src={logo} className='logo '/>
                <p className='headline1'>Student Registeration</p>
                <div className='inputer'>
                  <Form.Control type="text" placeholder= 'Username' className='loginput1' 
                  value={student_name} onChange={(e)=>setStudent_name(e.target.value)}/>
                  <Form.Control type="text" placeholder="Gender" className='loginput1' 
                  value={gender} onChange={(e)=>setGender(e.target.value)}/>
                  <Form.Control type="number" placeholder= 'Phone No' className='loginput1' 
                  value={phone_number} onChange={(e)=>setPhone_number(e.target.value)}/>
                  <Form.Control type="text" placeholder="Location" className='loginput1' 
                  value={location} onChange={(e)=>setLocation(e.target.value)}/>
                  <Form.Control type="email" placeholder= 'Email' className='loginput1' 
                  value={email} onChange={(e)=>setEmail(e.target.value)}/>
                  <Form.Control type="text" placeholder="Family Background" className='loginput1' 
                  value={desci} onChange={(e)=>setDescription(e.target.value)}/>
                  <Form.Control type="number" placeholder= 'Cut of Mark' className='loginput1' 
                  value={cutoff} onChange={(e)=>setCutoff(e.target.value)}/>
                  <Form.Control type="text" placeholder="Strem" className='loginput1' 
                  value={stream} onChange={(e)=>setStream(e.target.value)}/>
                  <Form.Control type="text" placeholder="School Type" className='loginput1' 
                  value={school_type} onChange={(e)=>setSchool_type(e.target.value)}/>
                  <button className='logbtn' onClick={handleClick}>Register</button>
                  <Link to='/Student-home' className='btn btn-danger' style={{marginLeft:"20px"}}> Cancel</Link>
                  </div>
                </div>
            </div>
            
        </div>
    );
}

 
export default Studentupdate;