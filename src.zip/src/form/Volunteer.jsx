import React, { useState } from 'react';
import '../form/Form.css'
import logo from '../asserts/LOGO.png' 
import 'bootstrap/dist/css/bootstrap.min.css';
import Form from 'react-bootstrap/Form';

const Volunteer = () => {
    const[volunteer_name,setVolunteer_name]=useState('')
    const[location,setLocation]=useState('')
    const[phone_number,setPhone_number]=useState('')
    const[gender,setGender]=useState('')
    const[profession,setProfession]=useState('')
    const[email,setEmail]=useState('')
    const password=`${volunteer_name}`+"2204"

    const handleClick=(e)=>{
        e.preventDefault()
        const volunteer={volunteer_name,phone_number,location,gender,profession,email,password}
        console.log(volunteer)
        fetch("http://localhost:8080/volunteer/add",{
            method:"POST",
            headers:{"content-type":"application/json"},
            body:JSON.stringify(volunteer)
        })
        .then(res=>res.json())
        .then((result)=>{
            console.log(result)
            console.log(result.statusMessage)
            if(result.statusMessage==="User Already Exists"){
                alert("User Already Exists please Enter New Details..");
                return result;
            }
            else if(result.statusMessage==="User Registered Successfully"){
                console.log("New volunteer added");
                alert("Successfully added your profile\nYour user name:"+`${email}`+"\nYour password is:"+`${password}`);
            return result;
        }
    
            alert("Something Error");
        })
    }

    return (
        <div>
            <div className='card-index' style={{margin:'4% -35% 0px 35%'}} >
               <div className='card-body'> <img src={logo} className='logo '/>
                <p className='headline1'>Volunteer Registration</p>
                <div className='inputer'>
                  <Form.Control type="text" placeholder= 'Username' className='loginput1' 
                  value={volunteer_name} onChange={(e)=>setVolunteer_name(e.target.value)}/>
                  <Form.Control type="text" placeholder="Gender" className='loginput1' 
                  value={gender} onChange={(e)=>setGender(e.target.value)}/>
                  <Form.Control type="number" placeholder= 'Phone No' className='loginput1' 
                  value={phone_number} onChange={(e)=>setPhone_number(e.target.value)}/>
                  <Form.Control type="text" placeholder="Location" className='loginput1'
                   value={location} onChange={(e)=>setLocation(e.target.value)}/>
                  <Form.Control type="email" placeholder= 'Email' className='loginput1'
                  value={email} onChange={(e)=>setEmail(e.target.value)} />
                  <Form.Control type="text" placeholder="Profession" className='loginput1' 
                  value={profession} onChange={(e)=>setProfession(e.target.value)}/>
                <Form.Control type="hidden" placeholder="Password" className='loginput1' 
                  value={password}/>
                  
                  <button className='logbtn' onClick={handleClick}>Register</button>
                  </div>
                </div>
            </div>
            
        </div>
    );
}
 
export default Volunteer;