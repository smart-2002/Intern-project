import React, { useState } from 'react';
import '../form/Form.css'
import logo from '../asserts/LOGO.png' 
import 'bootstrap/dist/css/bootstrap.min.css';
import Form from 'react-bootstrap/Form';
import { Navigate, useNavigate } from 'react-router';

const Student = () => {
    const[student_name,setStudent_name]=useState('')
    const[location,setLocation]=useState('')
    const[phone_number,setPhone_number]=useState('')
    const[gender,setGender]=useState('')
    const[desci,setDescription]=useState('')
    const[cutoff,setCutoff]=useState('')
    const[stream,setStream]=useState('')
    const[school_type,setSchool_type]=useState('')
    const[email,setEmail]=useState('')
    const password=`${student_name}`+"2204"
    const navigate=useNavigate()

    const handleClick=(e)=>{
        e.preventDefault()
        const student={student_name,phone_number,location,gender,desci,cutoff,stream,school_type,email,password}
        console.log(student)
        fetch("http://localhost:8080/Student/register",{
            method:"POST",
            headers:{"content-type":"application/json"},
            body:JSON.stringify(student)
        })
        .then(res=>res.json())
        .then((result)=>{
            console.log(result)
            console.log(result.statusMessage)
            if(result.statusMessage==="User Already Exists"){
                alert("User Already Exists please Enter New Details..");
                return result;
            }
            else if(result.statusMessage==="User Registered Successfully"){
                console.log("New student added");
                alert("Successfully added your profile\nYour user name:"+`${email}`+"\nYour password is:"+`${password}`);
                navigate('/')
            return result;
        }
    
            alert("Something Error");
        })
    }

    return (
        <div>
            <div className='card-index' style={{margin:'4% -35% 0px 35%'}} >
               <div className='card-body'> <img src={logo} className='logo '/>
                <p className='headline1'>Student Registeration</p>
                <div className='inputer'>
                  <Form.Control type="text" placeholder= 'Username' className='loginput1' 
                  value={student_name} onChange={(e)=>setStudent_name(e.target.value)}/>
                  <Form.Control type="text" placeholder="Gender" className='loginput1' 
                  value={gender} onChange={(e)=>setGender(e.target.value)}/>
                  <Form.Control type="number" placeholder= 'Phone No' className='loginput1' 
                  value={phone_number} onChange={(e)=>setPhone_number(e.target.value)}/>
                  <Form.Control type="text" placeholder="Location" className='loginput1' 
                  value={location} onChange={(e)=>setLocation(e.target.value)}/>
                  <Form.Control type="email" placeholder= 'Email' className='loginput1' 
                  value={email} onChange={(e)=>setEmail(e.target.value)}/>
                  <Form.Control type="text" placeholder="Family Background" className='loginput1' 
                  value={desci} onChange={(e)=>setDescription(e.target.value)}/>
                  <Form.Control type="number" placeholder= 'Cut of Mark' className='loginput1' 
                  value={cutoff} onChange={(e)=>setCutoff(e.target.value)}/>
                  <Form.Control type="text" placeholder="Strem" className='loginput1' 
                  value={stream} onChange={(e)=>setStream(e.target.value)}/>
                  <Form.Control type="text" placeholder="School Type" className='loginput1' 
                  value={school_type} onChange={(e)=>setSchool_type(e.target.value)}/>
                  <Form.Control type="hidden" placeholder="Password" className='loginput1' 
                  value={password}/>
                  <button className='logbtn' onClick={handleClick}>Register</button>
                  </div>
                </div>
            </div>
            
        </div>
    );
}

 
export default Student;