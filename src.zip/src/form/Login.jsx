import React, { useState } from 'react';
import '../form/Form.css'
import logo from '../asserts/LOGO.png' 
import 'bootstrap/dist/css/bootstrap.min.css';
import Form from 'react-bootstrap/Form';
import {Link, Navigate, useNavigate} from 'react-router-dom';


const Login = () => {
    const [email,setEmail]=useState('')
    const [password,setPassword]=useState('')
    const navigate=useNavigate()


    const navigateHome=()=>{
        navigate('/');
      };
    const handleClick=(e)=>{
        e.preventDefault()
        const user={email,password}
        console.log(user)
        fetch("http://localhost:8080/Student/login",{
            method:"POST",
            headers:{'content-type':'application/json'},
            body:JSON.stringify(user)
        })
        .then(res=>res.json())
        .then((result)=>{
            console.log(result)
            if(result.statusMessage==="Success"){
                console.log(result);
                alert("Success fully logined!!!");
                navigate(`/Student-home/${result.id}`);
                return result;
            }
            else if(result.statusMessage==="Failure"){
                alert("Password or username incorrect");
                return result;
            }
            console.log("Something failed!!");
        })
    }
    return (
        <div>
           <div >
           {/* <button className='pagehome' onClick={navigateHome}>Home </button> */}
            </div>
            <div className='card-index'>
                <img src={logo} className='logo'/>
                <p className='headline'>Login</p>
                <p className='account'>Sign in to your account</p>
                <div className='inputer'>
                  <Form.Control type="text" placeholder= 'Username' className='loginput' 
                  value={email} onChange={(e)=>setEmail(e.target.value)} required/>
                  <Form.Control type="password" placeholder="Password" className='loginput' 
                  value={password} onChange={(e)=>setPassword(e.target.value)} required/>
                  <button className='logbtn' onClick={handleClick}>Login</button>
                  <p className='forpass'>Forget password?  <a href='#'>click here to reset</a></p>
                  <Link to='/student-register' className='btn btn-primary' >Register New account</Link>
                </div>

            </div>
            
        </div>
    );
}
 
export default Login;