import React, { useEffect, useState } from 'react';
import '../form/Form.css'
import logo from '../asserts/LOGO.png' 
import 'bootstrap/dist/css/bootstrap.min.css';
import Form from 'react-bootstrap/Form';
import { Navigate, useNavigate, useParams } from 'react-router';
import ScholarshipService from '../service/ScholarshipService';

const ScholarshipUpdate = () => {
    const[name,setName]=useState('')
    const[opendate,setOpendate]=useState('')
    const[closedate,setClosedate]=useState('')
    const[guideline,setGuideline]=useState('')
    const[link,setLink]=useState('')
    const navigate=useNavigate()
    const {id1} = useParams();
    const handleClick=(e)=>{
        e.preventDefault()
        const application={name,opendate,closedate,guideline,link}
        console.log(application)
        fetch(`http://localhost:8080/application/update/${id1}`,{
            method:"PUT",
            headers:{"content-type":"application/json"},
            body:JSON.stringify(application)
        }).then(()=>{console.log("Updated")})
        .then(()=>{alert("updated....")})
        navigate(`/Foundation-home/${id1}`)
    
      }
    
      useEffect(() => {
        ScholarshipService.getApplicationById(id1).then((response) =>{
            setOpendate(response.data.opendate)
            setName(response.data.name)
            setClosedate(response.data.closedate)
            setGuideline(response.data.guideline)
            setLink(response.data.link)
        }).catch(error=>{
            console.log(error)
        })
      },[])
    

    return (
        <div>
            <div className='card-index' style={{margin:'4% -35% 0px 35%'}} >
               <div className='card-body'> <img src={logo} className='logo '/>
                <p className='headline1'>Scholarship Registeration</p>
                <div className='inputer'>
                  <Form.Control type="text" placeholder= 'Scholarship Name' className='loginput1' 
                  value={name} onChange={(e)=>setName(e.target.value)}/>
                  <Form.Control type="date" placeholder="Open Date" className='loginput1' 
                  value={opendate} onChange={(e)=>setOpendate(e.target.value)}/>
                  <Form.Control type="date" placeholder= 'Close Date' className='loginput1' 
                  value={closedate} onChange={(e)=>setClosedate(e.target.value)}/>
                  <Form.Control type="text" placeholder= 'Guideline' className='loginput1' 
                  value={guideline} onChange={(e)=>setGuideline(e.target.value)}/>
                  <Form.Control type="text" placeholder="Website Link" className='loginput1' 
                  value={link} onChange={(e)=>setLink(e.target.value)}/>
                  <button className='logbtn' onClick={handleClick}>Register</button>
                  </div>
                </div>
            </div>
            
        </div>
    );
}
 
export default ScholarshipUpdate;