import './App.css';
import Start from './component/Start';
import Login from './form/Login';
import Student from './form/Student'
import Volunteer from './form/Volunteer';
import Foundation from './form/Foundation';
import Func3 from './Hooksapi.jsx/Func3';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import DynamicGallery from './component/Gallery/DynamicColumn';
import ImageGallery from './component/Gallery/Gallery';
import Studentpage from './component/StudentHome';
import Studentupdate from './form/StudentUpdate';
import Foundationpage from './component/FoundationHome';
import FoundationLogin from './form/FoundationLogin';
import FoundationUpdate from './form/FoundationUpdate';
import ViewStudent from './component/ViewStudent';
import Scholarship from './form/Scholarship';
import ScholarshipUpdate from './form/ScholarshipUpdate';

function App() {
  return (
    <div>
      {/* <h1>React Photo Gallery</h1>
      <h2>Photo gallery Demo!</h2>
      <ImageGallery/> */}
      
      <Router><Routes>
      <Route path="/" element={<Start/>} />
      <Route path="/login" element={<Login/>}/> 
      <Route path="/foundation-login" element={<FoundationLogin/>}/>
      <Route path="/Student-register" element={<Student/>}/>
      <Route path="/Student-register/:id1" element={<Studentupdate/>}/>
      <Route path="/Volunteer-register" element={<Volunteer/>}/>
      <Route path="/Foundation-register" element={<Foundation/>}/>
      <Route path="/Foundation-register/:id1" element={<FoundationUpdate/>}/>
      <Route path="/Student-home/:id1" element={<Studentpage/>}/>
      <Route path="/Foundation-home/:id1" element={<Foundationpage/>}/>
      <Route path="/View-students" element={<ViewStudent/>}/>
      <Route path="/Scholarship-register" element={<Scholarship/>}/>
      <Route path="/Scholarship-register/:id1" element={<ScholarshipUpdate/>}/>
     </Routes>
     </Router>
     
    </div>
  );
}

export default App;
