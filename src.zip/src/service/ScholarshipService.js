import axios from "axios";

const Application_url = 'http://localhost:8080/application';

class ApplicationService{
    getAllApplications(){
        return axios.get(Application_url+'/getAll')
    }

    createStudent(application){
        return axios.post(Application_url+'/add',application)
        //console.log(instructor);
    }
    getApplicationById(applicationId){
        return axios.get(Application_url + '/' + applicationId)
    }

    deleteApplication(applicationId){
        return axios.delete(Application_url + '/' + applicationId);
    }
}

export default new ApplicationService();