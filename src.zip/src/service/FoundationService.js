import axios from "axios";

const Foundation_url = 'http://localhost:8080/foundation';

class FoundationService{
    getAllFoundations(){
        return axios.get(Foundation_url+'/getAll')
    }

    createStudent(foundation){
        return axios.post(Foundation_url+'/add',foundation)
        //console.log(instructor);
    }
    getFoundationById(foundationId){
        return axios.get(Foundation_url + '/' + foundationId)
    }

    deleteFoundation(foundationId){
        return axios.delete(Foundation_url + '/' + foundationId);
    }
}

export default new FoundationService();