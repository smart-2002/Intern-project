import axios from "axios";

const Student_url = 'http://localhost:8080/Student';

class StudentService{

    getAllStudents(){
        return axios.get(Student_url+'/getAll')
    }

    createStudent(student){
        return axios.post(Student_url+'/add',student)
        //console.log(instructor);
    }

    getStudentById(studentId){
        return axios.get(Student_url + '/' + studentId)
    }

    // updateInstructor(instructorId,instructor){
    //     return axios.put(Instructor_url + '/' +instructorId,instructor);
    // }

    deleteStudent(studentId){
        return axios.delete(Student_url + '/' + studentId);
    }

}

export default new StudentService();