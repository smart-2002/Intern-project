import React, { useEffect, useState } from 'react';
import './pages.css';
import logobg from '../asserts/LOGO-bg.png';
import {AiFillHome} from 'react-icons/ai'
import {HiOutlineLogout} from 'react-icons/hi'
import {BiSearch}from 'react-icons/bi' 
import Table from 'react-bootstrap/Table'
import {BsPersonCircle}from 'react-icons/bs'
import { Link, useNavigate, useParams } from 'react-router-dom';
import StudentService from '../service/StudentService';

const Studentpage = () => {

  const[student_name,setStudent_name]=useState('')
    const[location,setLocation]=useState('')
    const[phone_number,setPhone_number]=useState('')
    const[gender,setGender]=useState('')
    const[desci,setDescription]=useState('')
    const[cutoff,setCutoff]=useState('')
    const[stream,setStream]=useState('')
    const[school_type,setSchool_type]=useState('')
    const[email,setEmail]=useState('')

    const navigate = useNavigate();
  const {id1} = useParams();



  useEffect(() => {
    StudentService.getStudentById(id1).then((response) =>{
        setLocation(response.data.location)
        setStudent_name(response.data.student_name)
        setEmail(response.data.email)
        setGender(response.data.gender)
        setCutoff(response.data.cutoff)
        setPhone_number(response.data.phone_number)
        setStream(response.data.stream)
        setSchool_type(response.data.school_type)
        setDescription(response.data.desci)
    }).catch(error=>{
        console.log(error)
    })
  },[])
  
  // useEffect(() => {
  //   getAllStudents();
  
  // }, [])

  // const getAllStudents = () => {
  //   StudentService.getAllStudents().then((response)=>{
  //     setStudent(response.data)
  //     console.log(response.data);
  //   }).catch(error =>{
  //     console.log(error);
  //   })
  // }

  // const deleteStudent = (studentId) =>{
  //   // console.log(instructorId);
  //   StudentService.deleteStudent(studentId).then((response) => {
  //     getAllStudents();
  //     console.log(response.data);
  //   }).catch(error =>{
  //     console.log(error);
  //   })
  // }
    const navigateHome=()=>{
      navigate('/');
    };
    const navigateForm=()=>{
      navigate(`/Student-register/${id1}`);
    };
    return (
        <div>
        <div style={{borderBottom:'2px solid rgb(39, 182, 239)'}}className='navbar1'>
        <img className='logobg' src={logobg} style={{height:'100%',width:'10%',marginLeft:'4%'}}/>
        <h1 className='topic'>Schloarship Application portal</h1>
        <button className='logout'>Logout  <HiOutlineLogout/></button>
        <button className='pagehome' onClick={navigateHome}>Home  <AiFillHome/></button>
       </div>
       <div className='container'>
         <div className='card' style={{width:'100%',height:'300px',backgroundColor:'rgb(8, 170, 250)',borderRadius:'20px'}}>
           <h2 className='namefoundation'><BsPersonCircle/>  Hello {student_name}!</h2>
          <p className='pagecontant'style={{marginTop:'2%',fontSize:'20px'}}>Name   :<p className='pagenumber'>{student_name}</p></p>
          <p className='pagecontant'style={{fontSize:'20px',marginTop:'-4%'}}>Gender:<p className='pagenumber'>{gender}</p></p>
          <p className='pagecontant'style={{fontSize:'20px',marginTop:'-3%'}}>Phone No :<p className='pagenumber'>{phone_number}</p></p>
          <p className='pagecontant'style={{fontSize:'20px',marginTop:'-4.5%'}}>Location:<p className='pagenumber'>{location}</p></p>
          <p className='pagecontant'style={{fontSize:'20px',marginTop:'-3%'}}>Family Background :<p className='pagenumber'>{desci}</p></p>
          <p className='pagecontant'style={{fontSize:'20px',marginTop:'8%',marginLeft:'-6%'}}>Cuttoff Mark :<p className='pagenumber'>{cutoff}</p></p>
          <p className='pagecontant'style={{fontSize:'20px',marginTop:'-4%',marginLeft:'-6%'}}>Stream:<p className='pagenumber'>{stream}</p></p>
          <p className='pagecontant'style={{fontSize:'20px',marginTop:'-3%',marginLeft:'-6%'}}>Email:<p className='pagenumber'>{email}</p></p>
          <p className='pagecontant'style={{fontSize:'20px',marginTop:'-3%',marginLeft:'-6%'}}>School Type :<p className='pagenumber'>{school_type}</p></p>
        <div className='viwebtn'><button className='selectstu' onClick={navigateForm}>Update Profile</button><br></br>
        <button className='verifistu' style={{marginTop:'5%'}}>Contact Volunteer</button></div>
         </div>
         <div className='pageline'><div className='card' style={{width:'100%',height:'50px',backgroundColor:'rgb(8, 170, 250)',borderRadius:'20px',marginTop:'30px'}}>
           <h3 className='namefoundation'style={{marginLeft:'15%',}}>Applied Student</h3>
           <button className='viewall' style={{width:'30%'}}>Click Status to View Comments</button>
          
           </div></div>
           <Table striped bordered hover>
      <thead>
        <tr>
          <th>S.No</th>
          <th>Student Name</th>
          <th>Category</th>
          <th>View Student</th>
          <th>Assign Volunteer</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1.</td>
          <td>Abilash</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
        <tr>
        <td>2.</td>
          <td>Prashanth</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
        <tr>
        <td>3.</td>
          <td>Kabini</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
        <tr>
        <td>4.</td>
          <td>Malarkodi</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
        <tr>
        <td>5.</td>
          <td>Unknown</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
       
      </tbody>
    </Table>
        </div>
        </div>
    );
}
 

 

 
export default Studentpage;
