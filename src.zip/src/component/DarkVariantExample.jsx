import Carousel from 'react-bootstrap/Carousel';
import image2  from '../asserts/img-1.jpeg';
import image3 from '../asserts/img-2.jpeg';
import image4 from '../asserts/img-3.jpeg';
// import image5 from '../asserts/img-4.jpeg';
function DarkVariantExample() {
  return (
    <Carousel>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={image2}
           alt="First slide"
        style={{height:'300px'}}
        />
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={image3}
          alt="Second slide"
          style={{height:'300px'}}
        />
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={image4}
          alt="Third slide"
          style={{height:'300px'}}
        />
      </Carousel.Item>

    </Carousel>
  );
}

export default DarkVariantExample;
