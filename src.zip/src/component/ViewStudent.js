import React, { useEffect, useState } from 'react';
import Table from './Table';

export default function ViewStudent(){
    const[students,setStudents]=useState([])

    useEffect(()=>{
        fetch("http://localhost:8080/Student/getAll")
        .then(res=>res.json())
        .then((result)=>{
            setStudents(result);
        }
        )
    },[])

    return(
    <div>
        <h1>Students</h1>
            <div>
                <table  className='table table-striped'>
                <thead>
        <tr>
          <th>Student ID</th>
          <th>Student Name</th>
          <th>Location</th>
          <th>Number</th>
          <th>Gender</th>
          <th>Description</th>
          <th>Cutoff</th>
          <th>Stream</th>
          <th>School Type</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
                 {students.map(student=>(
                    <tr key={student.student_id}>
                        <td>{student.student_id}</td>
                        <td>{student.student_name}</td>
                        <td>{student.location}</td>
                        <td>{student.phone_number}</td>
                        <td>{student.gender}</td>
                        <td>{student.desci}</td>
                        <td>{student.cutoff}</td>
                        <td>{student.stream}</td>
                        <td>{student.school_type}</td>
                        <td>{student.email}</td>
                    </tr>
                ))}
                </tbody>
                </table>
            </div>
    </div>
    );
}