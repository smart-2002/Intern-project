import Card from 'react-bootstrap/Card';
import{FaBuffer} from 'react-icons/fa';
import{BsFillPersonFill}from 'react-icons/bs';
import{MdApartment}from 'react-icons/md';
import{BsPersonCircle}from 'react-icons/bs';
import{MdPublic}from 'react-icons/md';
import{FaHandPointRight}from 'react-icons/fa';
import{HiSpeakerphone}from 'react-icons/hi'

function TextExample() {
  return (
    <div style={{display:'flex', flexWrap:'wrap'}}>
    <Card style={{ width: '16rem',marginLeft:'20px'}} >
      <Card.Body>
        <Card.Title style={{backgroundColor:'rgb(39, 182, 239)',color:'white',border:'transparent',borderRadius:'10px'}}><FaBuffer/>  About us</Card.Title>
       
        <Card.Link style ={{textDecoration:'None',color:'black'}}href="#"><FaHandPointRight/> About Scholarship Management system</Card.Link><br></br>
        <Card.Link style ={{textDecoration:'None',color:'black'}} href="#"><FaHandPointRight/> Our Approach</Card.Link><br></br>
        <Card.Link style ={{textDecoration:'None',color:'black'}} href="#"><FaHandPointRight/> Connect with Us</Card.Link><br></br>
        
      </Card.Body>
    </Card>

<Card style={{ width: '16rem',marginLeft:'20px' }}>
<Card.Body>
  <Card.Title style={{backgroundColor:'rgb(39, 182, 239)',color:'white',border:'transparent',borderRadius:'10px'}}><BsFillPersonFill/>  Student Corner</Card.Title>
  
  <Card.Link style ={{textDecoration:'None',color:'black'}}href="/login"><FaHandPointRight/> Login</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="/Student-register"><FaHandPointRight/> Register</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="#"><FaHandPointRight/> View Scholarship Programs</Card.Link><br></br>

</Card.Body>
</Card>

<Card style={{ width:'16rem',marginLeft:'20px' }}>
<Card.Body>
  <Card.Title style={{backgroundColor:'rgb(39, 182, 239)',color:'white',border:'transparent',borderRadius:'10px'}}><MdApartment/>  Foundation/NGO Corner</Card.Title>
  
  <Card.Link style ={{textDecoration:'None',color:'black'}}href="/foundation-login"><FaHandPointRight/> Login</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="/Foundation-register"><FaHandPointRight/> Register</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="#"><FaHandPointRight/> Add New Schemes/Scholarhsips</Card.Link><br></br>

</Card.Body>
</Card>

<Card style={{ width: '16rem',marginLeft:'20px' }}>
<Card.Body>
  <Card.Title style={{backgroundColor:'rgb(39, 182, 239)',color:'white',border:'transparent',borderRadius:'10px'}}><BsPersonCircle/>  Volunteer Corner</Card.Title>
  
  <Card.Link style ={{textDecoration:'None',color:'black'}}href="/login"><FaHandPointRight/> Login</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="/Volunteer-register"><FaHandPointRight/> Register</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="#"><FaHandPointRight/> Latest Updates</Card.Link><br></br>

</Card.Body>
</Card>

<Card style={{ width: '16rem',marginLeft:'20px' }}>
<Card.Body>
  <Card.Title style={{backgroundColor:'rgb(39, 182, 239)',color:'white',border:'transparent',borderRadius:'10px'}}><MdPublic/>  General User</Card.Title>
  
  <Card.Link style ={{textDecoration:'None',color:'black'}}href="#"><FaHandPointRight/> View Gallery</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="#"><FaHandPointRight/> View Acheivements</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="#"><FaHandPointRight/> News Feed</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="#"><FaHandPointRight/> Application Process</Card.Link><br></br>
  <Card.Link style ={{textDecoration:'None',color:'black'}} href="#"><FaHandPointRight/> Contact Us</Card.Link><br></br>
</Card.Body>
</Card>

<Card style={{ width: '16rem',marginLeft:'20px' }}>
<Card.Body>
  <Card.Title style={{backgroundColor:'rgb(39, 182, 239)',color:'white',border:'transparent',borderRadius:'10px'}}><HiSpeakerphone/>  Announcement Corner</Card.Title>
  
  <Card.Link style ={{textDecoration:'None',color:'black'}}href="#"> Keep Checking this tab for latest updates about new scholarship schemes.</Card.Link><br></br>
</Card.Body>
</Card>

</div>
  );
}

export default TextExample;
