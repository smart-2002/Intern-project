import React, { useEffect, useState } from 'react';
import './pages.css';
import logobg from '../asserts/LOGO-bg.png';
import {AiFillHome} from 'react-icons/ai'
import {HiOutlineLogout} from 'react-icons/hi'
import {BiSearch}from 'react-icons/bi' 
import Table from 'react-bootstrap/Table'
import FoundationService from '../service/FoundationService';
import { useNavigate, useParams } from 'react-router';
import StatictableInside from './StaticInside';

const Foundationpage = () => {
  const[name,setName]=useState('')
    const[location,setLocation]=useState('')
    const[phone_no,setPhone_number]=useState('')
    const[no_of_seats,setNo_of_seats]=useState('')
    const[des,setDescription]=useState('')
    const[website,setWebsite]=useState('')
    const[email,setEmail]=useState('')

    const navigate = useNavigate();
  const {id1} = useParams();



  useEffect(() => {
    FoundationService.getFoundationById(id1).then((response) =>{
        setLocation(response.data.location)
        setName(response.data.name)
        setEmail(response.data.email)
        setNo_of_seats(response.data.no_of_seats)
        setWebsite(response.data.website)
        setPhone_number(response.data.phone_number)
        setDescription(response.data.des)
    }).catch(error=>{
        console.log(error)
    })
  },[])

  const navigateHome=()=>{
    navigate('/');
  };
  const navigateViewStudents=()=>{
    navigate('/View-students');
  };
  const navigateScholarship=()=>{
    navigate('/Scholarship-register');
  };
  const navigateForm=()=>{
    navigate(`/Student-register/${id1}`);
  };
    return (
        <div>
        <div style={{borderBottom:'2px solid rgb(39, 182, 239)'}}className='navbar1'>
        <img className='logobg' src={logobg} style={{height:'100%',width:'10%',marginLeft:'4%'}}/>
        <h1 className='topic'>Schloarship Application portal</h1>
        <button className='logout'>Logout <HiOutlineLogout/></button>
        <button className='pagehome'  onClick={navigateHome}>Home  <AiFillHome/></button>
       </div>
       <div className='container'>
         <div className='card' style={{width:'100%',height:'300px',backgroundColor:'rgb(8, 170, 250)',borderRadius:'20px'}}>
           <h2 className='namefoundation'>Hello {name} Foundation!</h2>
          <p className='pagecontant'style={{marginTop:'2%'}}>Number of Seats   :<p className='pagenumber'>{no_of_seats}</p></p>
          
          <p className='pagecontant'style={{marginTop:'-3%'}}>Description :<p className='pagenumber'>{des}</p></p>
        <div className='viwebtn'><button className='selectstu' onClick={navigateScholarship}>Add Scholarships</button><br></br>
        <button className='verifistu' style={{marginTop:'5%'}} onClick={navigateViewStudents}>View Students</button></div>
         </div>
         {/* <div className='pageline'><div className='card' style={{width:'100%',height:'50px',backgroundColor:'rgb(8, 170, 250)',borderRadius:'20px',marginTop:'30px'}}>
           <h3 className='namefoundation'style={{marginLeft:'15%',}}>Applied Student</h3>
           <button className='viewall'>View All Students</button>
           <input placeholder='Search' className='pagesearch'/><button className='searchbtn'><BiSearch/></button>
           </div></div>
           <Table striped bordered hover>
      <thead>
        <tr>
          <th>S.No</th>
          <th>Student Name</th>
          <th>Category</th>
          <th>View Student</th>
          <th>Assign Volunteer</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1.</td>
          <td>Abilash</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
        <tr>
        <td>2.</td>
          <td>Prashanth</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
        <tr>
        <td>3.</td>
          <td>Kabini</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
        <tr>
        <td>4.</td>
          <td>Malarkodi</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
        <tr>
        <td>5.</td>
          <td>Unknown</td>
          <td>UG</td>
          <td><a href='#'>View Student</a></td>
          <td><a href='#'>Assign Volunteer</a></td>
        </tr>
       
      </tbody>
    </Table> */}
    <StatictableInside/>
        </div>
        </div>
    );
}
 

 
export default Foundationpage;
