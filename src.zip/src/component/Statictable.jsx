import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table'
import { Link } from 'react-router-dom';
 
const Statictable = () => {

  const[applications,setApplications]=useState([])

  useEffect(()=>{
      fetch("http://localhost:8080/application/getAll")
      .then(res=>res.json())
      .then((result)=>{
          setApplications(result);
      }
      )
  },[])

    return (
        <div>
            <Table striped bordered hover>
      <thead>
        <tr>
          <th>Schloarship Name</th>
          <th>Application Open Date</th>
          <th>Application Close Date</th>
          <th>Guidline</th>
          <th>Apply</th>
        </tr>
      </thead>
      <tbody>
      {applications.map(application=>(
                    <tr key={application.id}>
                      <td>{application.name}</td>
                      <td>{application.opendate}</td>
                      <td>{application.closedate}</td>
                      <td><a href={application.guideline}>Guidline</a></td>
                      <td><a href={application.link}>Apply</a></td>
                    </tr>
                ))}
        {/* <tr>
          <td>Pre Matric Scholarships Scheme for Minorities</td>
          <td>12/5/2020</td>
          <td>12/6/2020</td>
          <td><a href='#'>Guidline</a></td>
          <td><a href='#'>Apply</a></td>
        </tr>
        <tr>
          <td>Post Matric Scholarships Scheme for Minorities</td>
          <td>12/7/2020</td>
          <td>12/9/2020</td>
          <td><a href='#'>Guidline</a></td>
          <td><a href='#'>Apply</a></td>
        </tr>
        <tr>
          <td>Merit Cum Means Scholarship For Professional and Technical Courses CS</td>
          <td>10/1/2022</td>
          <td>22/2/2022</td>
          <td><a href='#'>Guidline</a></td>
          <td><a href='#'>Apply</a></td>
        </tr>
        <tr>
          <td>BEGUM HAZRAT MAHAL NATIONAL SCHOLARSHIP</td>
          <td>10/4/2022</td>
          <td>12/5/2022</td>
          <td><a href='#'>Guidline</a></td>
          <td><a href='#'>Apply</a></td>
        </tr>
        <tr>
          <td>Post-matric Scholarship for Students with Disabilities</td>
          <td>1/8/2022</td>
          <td>1/11/2022</td>
          <td><a href='#'>Guidline</a></td>
          <td><a href='#'>Apply</a></td>
        </tr>
        */}
      </tbody>
    </Table>
        </div>
    );
}
 
 
export default Statictable;