import React from 'react';
import DarkVariantExample from './DarkVariantExample';
import TextExample from './TextExample';
import 'bootstrap/dist/css/bootstrap.min.css';
import{IoIosMail}from 'react-icons/io';
import {BsFillTelephoneInboundFill}from 'react-icons/bs'
import './Start.css'
import NavPillsExample from './NavPillsExample';
import FlushExample from "./FlushExample"
import Table from './Table';
import Statictable from './Statictable';
import logo from '../asserts/LOGO.png';
import {FaBell} from "react-icons/fa";
import ngologo from '../asserts/ngo.png';
import Footer from './Footer';

const Start = () => {
    return (
     <div>
        <div style={{borderBottom:'2px solid red'}}className='navbar'>
    <img className='image' src={logo} style={{height:'100%',width:'10%',marginLeft:'4%'}}/>
    <h1 className='header'>Schloarship Application portal</h1>
    <a href='#' className='bell'><div className='ring'><FaBell/>Important Notice</div><img src={ngologo}/></a>
    
          </div>
        
        <p className='contact'>Please check the Announcement corner regularly for latest updates and information.
For any technical queries, please contact Helpdesk at  <p><IoIosMail/>  supercooper.cooper@gmail.com or  <BsFillTelephoneInboundFill/> 9876543210</p><article>(from 8 AM to 8 PM on all days, excluding holidays)</article></p>

     <div className='carosul' ><DarkVariantExample/></div>
     <div className='card card-body bodycorner' style={{backgroundColor:'rgb(39, 182, 239)'}}><TextExample/></div>
     <div className='container'><Statictable/></div>
     {/* <div className='container'><Table/></div> */}
     {/* <div><FlushExample/></div> */}
     <div><Footer/></div>
        </div>
    );
}
 

 
export default Start;
