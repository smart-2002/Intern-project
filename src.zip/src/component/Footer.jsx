import React from 'react';
import{BsFacebook} from 'react-icons/bs'
import './Start.css';
import{BsTwitter} from 'react-icons/bs';
import{AiFillInstagram} from 'react-icons/ai';
import{BsLinkedin} from 'react-icons/bs';

const Footer = () => {
    return (
        <div className='footer'>
            <div className='media'>
            <a href='#'><BsFacebook/></a>
            <a href='#'><BsTwitter/></a>
            <a href='#'><AiFillInstagram/></a>
            <a href='#'><BsLinkedin/></a>
            </div>
            <div className='bar'>
            <a href='/'>Home</a>
            <a href='#'>About</a>
            <a href='#'>Gallary</a>
            <a href='#'>Contact</a>
            </div>
            <p className='copytex'>copyright@Schloarship Application Portal</p>
            
        </div>
    );
}
 
 
export default Footer;
