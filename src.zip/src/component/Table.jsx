import React, { useState } from "react";
import '../component/Start.css';

function Table(){
const[food,setFood]=useState(

  [
        {
          id: 1,
          title: 'buttermilk pancakes',
          price:'21/3/2020',
          date:'21/12/2020',
          category: 'Maatram Foundation',
        },
        {
          id: 2,
          title: 'diner double',
          price:'5/2/2022',
          date:'3/4/2022',
          category: 'Maatram Foundation',
         },
        {
          id: 3,
          title: 'godzilla milkshake',
          price:'3/1/2022',
          date:'1/2/2022',
          category: 'Maatram Foundation',
         },
        {
          id: 4,
          title: 'country delight',
          price:'21/2/2022',
          date:'11/3/2022',
          category: 'Agaram Foundation',
         },
        {
          id: 5,
          title: 'egg attack',
          price:'21/1/2022',
          date:'21/2/2022',
          category: 'Agaram Foundation',
         },
       
    ]
)
const[datarender,setDatarender]=useState(food)
const items = food.map(f=>f.category)
// console.log(items)
const uniqitem = [...new Set(items)]
// console.log(uniqitem)
uniqitem.unshift("All Foundation")

const handlechange=(ch)=>{
    // console.log("show" ,ch)
    if(ch === "All Foundation"){
        setDatarender(food)
        return
    }
  const filterdata=food.filter(data=>data.category===ch)
   setDatarender(filterdata)
}
    return(

        <div>
            {uniqitem.map(uni=><span onClick={()=>handlechange(uni)}>{uni}</span>)}
  <div>
  <table>
  <tr><th>Schloarship Name</th><th>Application Open Date</th><th>Application Close Date</th><th>Guidline</th><th>Apply</th></tr>
  {datarender.map(f =><div>
    
    <tr><td><p>{f.title}</p></td></tr>
    <tr><td><p>{f.price}</p></td></tr>
    <tr><td><p>{f.date}</p></td></tr>
    <tr><td><a href="#">Guidline</a></td></tr>
    <tr> <td><a href="#">Apply</a></td></tr>
    </div>)}
    </table>
  </div>

        </div>
    )
}
export default Table